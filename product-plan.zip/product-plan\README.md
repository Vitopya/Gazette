# PokeWatch — Design Handoff

This folder contains everything needed to implement PokeWatch.

## What's Included

**Ready-to-Use Prompts:**
- `prompts/one-shot-prompt.md` — Prompt template for full implementation
- `prompts/section-prompt.md` — Prompt template for section-by-section implementation

**Instructions:**
- `product-overview.md` — Product summary (provide with every implementation)
- `instructions/one-shot-instructions.md` — All milestones combined for full implementation
- `instructions/incremental/` — Milestone-by-milestone instructions (shell, then sections)

**Design Assets:**
- `design-system/` — Colors, fonts, design tokens
- `data-shapes/` — UI data contracts (the shapes of data components expect)
- `shell/` — Application shell components
- `sections/` — All section components, types, sample data, and test specs

## How to Use This

### Option A: Incremental (Recommended)

Build your app milestone by milestone for better control:

1. Copy the `product-plan/` folder to your codebase
2. Start with Shell (`instructions/incremental/01-shell.md`) — includes design tokens and application shell
3. For each section:
   - Open `prompts/section-prompt.md`
   - Fill in the section variables at the top (SECTION_NAME, SECTION_ID, NN)
   - Copy/paste into your coding agent
   - Answer questions and implement
4. Review and test after each milestone

### Option B: One-Shot

Build the entire app in one session:

1. Copy the `product-plan/` folder to your codebase
2. Open `prompts/one-shot-prompt.md`
3. Add any additional notes to the prompt
4. Copy/paste the prompt into your coding agent
5. Answer the agent's clarifying questions
6. Let the agent plan and implement everything

## Testing

Each section includes a `tests.md` file with UI behavior test specs. For best results:

1. Read `sections/[section-id]/tests.md` before implementing
2. Write tests for key user flows
3. Implement the feature to make tests pass
4. Refactor while keeping tests green

The test specs are **framework-agnostic** — they describe WHAT to test (user-facing behavior), not HOW. Adapt to your testing setup.

## Tips

- **Use the pre-written prompts** — They prompt for important clarifying questions about your tech stack and requirements.
- **Add your own notes** — Customize prompts with project-specific context when needed.
- **Build on your designs** — Use completed sections as the starting point for future feature development.
- **Review thoroughly** — Check plans and implementations carefully to catch details and inconsistencies.
- **The components are flexible** — They accept data and fire callbacks. How you architect the backend is up to you.

